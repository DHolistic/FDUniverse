# Chapter 13 — Placeholder

This is a placeholder for Chapter 13. Replace this content with the actual chapter script or prose.

## Scene 1

- Setting: The archive, quiet after dusk.
- Caption: "Methodius contemplates the translation."

Dialogue:

> "Words change the world, but some words must remain buried."


(End placeholder)
